# Level 2 — Exercises

1. Mindful Observation:
   - Sit quietly and note emotional signals.
   - Do **not react or judge**.
2. Signal Logging:
   - Write down detected feelings and intensity.
   - Ensure Observer remains stable.
3. Simulation:
   - Recall an emotional memory.
   - Track feeling signals **without emotional fusion**.
4. Attention Test:
   - Focus on one sensory input while observing feelings.
   - Check for attention drift.
