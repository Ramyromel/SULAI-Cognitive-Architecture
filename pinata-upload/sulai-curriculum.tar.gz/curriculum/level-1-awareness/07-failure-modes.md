# Level 1 — Failure Modes

## Mode A1-1: Thought Hijacking
Rapid mental labeling before observation

## Mode A1-2: Emotional Override
Reacting to feelings instead of logging

## Mode A1-3: Impatience Drift
Rushing exercises, skipping pauses

## Mode A1-4: Narrative Construction
Creating stories rather than noting raw observation

**Failure Response:**  
Return to Zero Chapter protocols if persistent.
