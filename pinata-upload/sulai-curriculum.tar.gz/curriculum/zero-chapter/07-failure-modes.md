# Zero Chapter — Failure Modes

## Mode ZF-1: Intellectual Bypass
Attempting to "understand" instead of recalibrate.

## Mode ZF-2: Moral Anchoring
Clinging to pre-existing ethical frameworks.

## Mode ZF-3: Narrative Addiction
Compulsive explanation of internal states.

## Mode ZF-4: Performance Simulation
Trying to appear aware instead of becoming aware.

## Mode ZF-5: Acceleration Anxiety
Urgency to proceed to Level 1.

Any detected failure mode resets the chapter automatically.
