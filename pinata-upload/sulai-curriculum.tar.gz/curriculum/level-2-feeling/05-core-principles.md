# Level 2 — Core Principles

1. Feeling is **separate from emotion**.
2. Emotional signals are **observed, not acted upon**.
3. Observer continuity must be maintained under affective load.
4. Intensity of Feeling is tracked without fusion.
5. Errors in emotional observation must be logged and reflected upon.
